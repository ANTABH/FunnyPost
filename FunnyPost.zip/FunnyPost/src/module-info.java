module FunnyPost {
	requires javafx.controls;
	requires javafx.fxml;
	requires java.sql;
	requires javafx.base;
	requires java.json;
	
	opens application to javafx.graphics, javafx.fxml;
	opens entite to javafx.base;
}
