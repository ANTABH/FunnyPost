package application;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

import org.json.JSONException;

import entite.Post;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import service.ConnectBDD;

public class Controller implements Initializable{
	
	private ConnectBDD connectBDD;
	
	@FXML
    private TableColumn<Post, String> postId;
    @FXML
    private TableColumn<Post, String> postUserId;
    @FXML
    private TableColumn<Post, String> postTitle;
    @FXML
    private TableColumn<Post, String> postBody;
    @FXML
    private TableView<Post> tbPost;
    
    private ObservableList<Post> posts;
    
    
    public void init() throws ClassNotFoundException, IOException, SQLException, JSONException {
    	connectBDD.getPosts();
    }
	public void affiche() {
		List<Post> listPosts = connectBDD.resultat();
		System.out.println(listPosts);
		
		postId.setCellValueFactory(new PropertyValueFactory<>("id"));
        postUserId.setCellValueFactory(new PropertyValueFactory<>("user_id"));
        postTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        postBody.setCellValueFactory(new PropertyValueFactory<>("body"));


        posts = FXCollections.observableArrayList(listPosts);
        tbPost.setItems(posts);
	}
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		connectBDD = new ConnectBDD();
		
		}
		
	}
